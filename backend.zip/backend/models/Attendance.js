const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema({
  employeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Employee",
    required: true
  },
  employeeName: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  checkIn: {
    type: String,
    required: true
  },
  checkOut: {
    type: String,
    default: null
  },
  status: {
    type: String,
    enum: ["present", "absent", "leave", "half-day"],
    required: true
  },
}, { timestamps: true });

module.exports = mongoose.model("Attendance", attendanceSchema);
