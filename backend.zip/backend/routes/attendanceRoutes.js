const express = require("express");
const router = express.Router();
const { markAttendance, getHistory } = require("../controllers/attendanceController");

router.post("/mark", markAttendance);
router.get("/history/:employeeId", getHistory);

module.exports = router;
